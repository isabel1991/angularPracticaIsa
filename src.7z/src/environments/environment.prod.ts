export const environment = {
  production: true,
  clientesApi: 'https://northwind.now.sh/api/customers',
};
